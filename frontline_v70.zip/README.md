# Frontline: Castle Defense — Online Multiplayer

## Quick Start

```bash
npm install
node server.js
```

Open `http://localhost:3000` in your browser.

## Directory Structure

```
├── server.js          # Authoritative Node.js game server
├── package.json       # Dependencies
├── README.md          # This file
└── public/
    └── index.html     # Multiplayer client (copy from outputs)
```

**Setup:** Create a `public/` folder and put `index.html` inside it.

## How It Works

### Architecture
- **Authoritative Server** — All game logic (physics, AI, damage, spawning) runs on `server.js` at 60Hz. Clients cannot cheat.
- **Client** — Sends key inputs, receives compressed state snapshots, renders locally.
- **Socket.IO** — WebSocket transport with HTTP long-poll fallback.

### Deployment

**Locally:**
```bash
npm install
node server.js
# Server at http://localhost:3000
```

**Free cloud (Render.com):**
1. Push to GitHub
2. New Web Service → connect repo
3. Build: `npm install`  Start: `node server.js`
4. Free tier = 1 server, ~512MB RAM (supports ~10 concurrent rooms)

**Railway / Fly.io** also work — just set `PORT` env var.

### Playing
1. Open the URL in your browser
2. Click **CREATE ROOM** — share the 5-character code with friends
3. Friends click **JOIN ROOM** and enter your code
4. Host selects the map, clicks **START GAME**
5. Click **PLAY SOLO** to play offline (full single-player mode)

### Controls (Multiplayer — all players use same keyboard locally, or separate browsers online)
| Action | P1 |
|--------|-----|
| Move | A / D |
| Jump | W |
| Shoot / Place | F |
| Build Mode | E |
| Cycle Structure | Q |
| Cycle Back | 1 |
| Change Material | Z / X |
| Demolish | R |
| Repair | C |
| Start Wave | Space |
| Chat (online) | T |

### Mobile
Touch controls appear automatically on touch devices:
- **Left joystick** — move + jump
- **🔫 Shoot** button (hold = auto-fire)
- **🏗 Build** — toggle build mode
- **↻ Cycle** — cycle structures/guns
- **🔧 Repair** — repair nearby structure
- **▶ Space** — start wave / ready up

## Technical Notes

- Room capacity: 4 players max
- Tick rate: 60Hz server-side
- State broadcast: every 2 ticks (~30fps) to save bandwidth
- Rooms auto-delete when all players disconnect
- In-memory only — no database needed (add Supabase later for cross-platform saves)
